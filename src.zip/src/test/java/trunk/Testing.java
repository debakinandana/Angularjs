package trunk;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import com.marklogic.client.DatabaseClient;
import com.marklogic.client.DatabaseClientFactory;
import com.marklogic.client.Transaction;
import com.marklogic.client.DatabaseClientFactory.Authentication;
import com.marklogic.client.admin.QueryOptionsManager;
import com.marklogic.client.document.XMLDocumentManager;
import com.marklogic.client.io.DocumentMetadataHandle;
import com.marklogic.client.io.StringHandle;
import com.marklogic.client.io.ValuesHandle;
import com.marklogic.client.query.CountedDistinctValue;
import com.marklogic.client.query.QueryManager;
import com.marklogic.client.query.StructuredQueryBuilder;
import com.marklogic.client.query.StructuredQueryDefinition;
import com.marklogic.client.query.ValuesDefinition;
import com.xvitcoder.springmvcangularjs.model.Customer;

public class Testing {
public static void main(String args[]) throws IOException, ParseException{
	DatabaseClient client = DatabaseClientFactory.newClient(
			"172.21.106.164", 8000, "Erie_Insurance-FINAL","admin", "admin", Authentication.DIGEST);
	//to read the object of the appropriate subclass for the document format (XML).
	XMLDocumentManager docMgr = client.newXMLDocumentManager();

	// do the next eight lines just once
	String options =
			"<options xmlns='http://marklogic.com/appservices/search'>" +
					"  <values name='uris'>" +
					"    <uri/>" +
					"  </values>" +
					"</options>";

	List<String> allXMLNames=new ArrayList<String>();
	QueryOptionsManager optionsMgr = client.newServerConfigManager().newQueryOptionsManager();
	optionsMgr.writeOptions("uriOptions", new StringHandle(options));
	//create an print writer for writing to a file
	PrintWriter out = new PrintWriter(new FileWriter("D://output.txt"));
	// run the following each time you need to list all uris
	QueryManager queryMgr1 = client.newQueryManager();
	long pageLength = 10000;
	queryMgr1.setPageLength(pageLength);
	ValuesDefinition query = queryMgr1.newValuesDefinition("uris", "uriOptions");
	StructuredQueryBuilder sb =  queryMgr1.newStructuredQueryBuilder("filtered");
	//StructuredQueryDefinition criteria = sb.containerQuery(sb.jsonProperty("First_Name"), sb.and( sb.word(sb.jsonProperty("StatusVal"), "2")));
	query.setQueryDefinition(sb.and(sb.and(sb.word(sb.jsonProperty("StatusVal"), "2"),sb.collection("Customer"))));
	//query.setQueryDefinition(sb.and(sb.collection("Customer")));
	int start = 1;
	boolean hasMore = true;
	Transaction transaction = client.openTransaction();
	try {
		while ( hasMore ) {
			CountedDistinctValue[] uriValues =
					queryMgr1.values(query, new ValuesHandle(), start, transaction).getValues();
			for (CountedDistinctValue uriValue : uriValues) {
				String uri = uriValue.get("string", String.class);
				//output to the file a line
				out.println(uri);
					allXMLNames.add(uri);
				 System.out.println(uri);
			}
			start += uriValues.length;
			// this is the last page if uriValues is smaller than pageLength
			hasMore = uriValues.length == pageLength;
		}
	} finally {
		transaction.commit();
		out.close();
		System.out.println("customer size==="+allXMLNames.size());
	}
	
	int customerSize = (allXMLNames.size()+10-1)/10;
	
	List<Customer> custList=new ArrayList<Customer>();
	//List<GDObject> gdObjectList=new ArrayList<GDObject>();
	int counter=0;
	for(String xmlName:allXMLNames){
		if(counter>10){
			break;
		}
		
	
		// create a handle to receive the document content
		StringHandle content = new StringHandle();
		// create a handle to receive the document metadata
		DocumentMetadataHandle metadata = new DocumentMetadataHandle();
		// read the document content
		docMgr.read(xmlName, metadata, content);
		System.out.println("content type==="+content.getFormat());
		
		
		JSONParser parser = new JSONParser();
		JSONObject jsonObject = (JSONObject) parser.parse(content.toString());
		JSONObject jsonChildObject = (JSONObject)jsonObject.get("content");
		Set jsonObjSet=jsonChildObject.keySet();
		String custName=(String) jsonChildObject.get("First_Name");
		if(custName!=null){
			counter++;
			Customer cust=new Customer();
			cust.setDocumentName(xmlName);
			cust.setCustomerName((String) jsonChildObject.get("First_Name")+" "+(String) jsonChildObject.get("Middle_Name")+" "+(String) jsonChildObject.get("Last_Name"));
			//cust.setLocation(((String) jsonChildObject.get("Location")));
			String age=(String) jsonChildObject.get("Age");
			cust.setCustAge((String)age);
			String custId=(String) jsonChildObject.get("CustomerID");
			cust.setCustomerId(custId);
			String genderId=(String) jsonChildObject.get("Gender");
			cust.setGender(genderId);
			/*String income=(String) jsonChildObject.get("Income");
			cust.setIncome(income);*/
			//cust.setDeniedClaims(Integer.parseInt((String) jsonChildObject.get("Customer_Name")));
			//cust.setLocationOfService((String) jsonChildObject.get("Customer_Name"));
		//	long zipcode=(String) jsonChildObject.get("Zip_Code");
			cust.setOccupationName((String) jsonChildObject.get("Occupation"));
			cust.setZipCode((String) jsonChildObject.get("ZIP"));
			
			//cust.setAgencyName((String) jsonChildObject.get("Customer_Name"));
			custList.add(cust);
		}
}
}
}