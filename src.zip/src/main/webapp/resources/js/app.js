'use strict';

/*var AngularSpringApp = {};*/

var App = angular.module('AngularSpringApp', ['AngularSpringApp.filters', 'AngularSpringApp.services', 
                                              'AngularSpringApp.directives','ngRoute','ui.grid','ui.grid.pagination','ngAnimate', 'ui.grid.expandable','ngTouch', 'ui.grid.selection', 'ui.grid.pinning']);

// Declare app level module which depends on filters, and services
/*,'ui.grid','ui.grid.pagination'*/
App.config(['$routeProvider', function ($routeProvider) {
    $routeProvider.when('/cars', {
        templateUrl: 'cars/layout',
        controller: CarController
    })

    .when('/trains', {
        templateUrl: 'trains/layout',
        controller: TrainController
    })
    
    .when('/railwaystations', {
        templateUrl: 'railwaystations/layout',
        controller: RailwayStationController
    })

    .otherwise({redirectTo: '/cars'});
}]);
