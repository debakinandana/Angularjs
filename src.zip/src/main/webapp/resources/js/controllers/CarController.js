'use strict';

/**
 * CarController
 * @constructor
 */
//var app = angular.module('AngularSpringApp', ['ngTouch', 'ui.grid', 'ui.grid.expandable', 'ui.grid.selection', 'ui.grid.pinning']);
//app.controller('CarController', ['$scope', '$http', '$log', function ($scope, $http, $log) {
var CarController = function($scope, $http, $log) {
    $scope.fetchCarsList = function() {
        $http.get('cars/carlist.json').success(function(carList){
            $scope.cars = carList;
        });
    };

    $scope.addNewCar = function(newCar) {
        $http.post('cars/addCar/' + newCar).success(function() {
            $scope.fetchCarsList();
        });
        $scope.carName = '';
    };

    $scope.removeCar = function(car) {
        $http.delete('cars/removeCar/' + car).success(function() {
            $scope.fetchCarsList();
        });
    };

    $scope.removeAllCars = function() {
        $http.delete('cars/removeAllCars').success(function() {
            $scope.fetchCarsList();
        });

    };   
    
    
    $scope.getAllCustomerDetails=function()
    {    	
    	
    	 $http.get('cars/carlist.json').success(function(carList){
             $scope.cars = carList;
         	$scope.gridOptions.data = $scope.cars; 
         	console.log( $scope.cars);
         });
    }
    
	/*$scope.gridOptions = {
    		paginationPageSizes: [25, 50, 75],
    		paginationPageSize: 10, 
    		enableSorting: true,
    	     fastWatch: true,
    		
    		enableHorizontalScrollbar: 1,
    		enableVerticalScrollbar: 1,
    		fixedWidth: true,
    		editorType: 'checkbox',
    		editorSettings: {
    			style: {
    			general: 'checkbox',
    			box: {
    			general: 'checkbox-box',
    			checked: 'checkbox-checked',
    			unchecked: 'checkbox-unchecked'
    			}
    			}
    			},
    		scrollX: true,
    		columnDefs: [
    		
    		{ field: 'checkbox',cellTemplate: '<input type="checkbox" ng-model="row.entity.rowId" ng-click="$event.stopPropagation();">' },
    		{ field: 'customerId'},
    		{ field: 'salutation' },
    		{ field: 'customerName' },
    		{ field: 'gender' },
    		{ field: 'dob' },
    		{ field: 'custAge' },
    		{ field: 'education' },
    		{ field: 'occupationName' },
    		{ field: 'maritalStatus' },
    		{ field: 'address' },
    		{ field: 'zipCode' },
    		{ field: 'phone' },
    		{ field: 'employer' },
    		
    		{ field: 'email' }
    		],
    		
            scrollX: true,
    		enablePaging: true,
    		enableHorizontalScrollbar: 0,
    		onRegisterApi: function (gridApi) {
    		$scope.grid1Api = gridApi;
    		}
    		};
	*/
    
    $scope.gridOptions = {
    	    expandableRowTemplate: 'subgrid.html',
    	    expandableRowHeight: 150,
    	    //subGridVariable will be available in subGrid scope
    	    expandableRowScope: {
    	      subGridVariable: 'subGridScopeVariable'
    	    }
    	  }
    	 
    	  $scope.gridOptions.columnDefs = [
    		  { field: 'customerId',pinnedLeft:true},
	    		{ field: 'salutation' },
	    		{ field: 'customerName' },
	    		{ field: 'gender' },
	    		{ field: 'dob' },
	    		{ field: 'custAge' },
	    		{ field: 'education' },
	    		{ field: 'occupationName' },
	    		{ field: 'maritalStatus' },
	    		{ field: 'address' },
	    		{ field: 'zipCode' },
	    		{ field: 'phone' },
	    		{ field: 'employer' },
	    		
	    		{ field: 'email' }
    	  ];
    	 
    	  $http.get('cars/carlist.json')
    	    .success(function(data) {
    	      for(i = 0; i < data.length; i++){
    	        data[i].subGridOptions = {
    	          columnDefs: [ {name:"Id", field:"id"},{name:"Name", field:"name"} ],
    	          data: data[i].friends
    	        }
    	      }
    	      $scope.gridOptions.data = data;
    	    });
    	 
    	    $scope.gridOptions.onRegisterApi = function(gridApi){
    	      $scope.gridApi = gridApi;
    	    };
    	 
    	    $scope.expandAllRows = function() {
    	      $scope.gridApi.expandable.expandAllRows();
    	    }
    	 
    	    $scope.collapseAllRows = function() {
    	      $scope.gridApi.expandable.collapseAllRows();
    	    }
    	};
    	 
    	app.controller('CarController', ['$scope', '$http', '$log', function ($scope, $http, $log) {
    	      $scope.gridOptions = {
    	        enableRowSelection: true,
    	        expandableRowTemplate: 'subgrid.html',
    	        expandableRowHeight: 150
    	      }
    	 
    	      $scope.gridOptions.columnDefs = [
    	    	  { field: 'customerId'},
    	    		{ field: 'salutation' },
    	    		{ field: 'customerName' },
    	    		{ field: 'gender' },
    	    		{ field: 'dob' },
    	    		{ field: 'custAge' },
    	    		{ field: 'education' },
    	    		{ field: 'occupationName' },
    	    		{ field: 'maritalStatus' },
    	    		{ field: 'address' },
    	    		{ field: 'zipCode' },
    	    		{ field: 'phone' },
    	    		{ field: 'employer' },
    	    		
    	    		{ field: 'email' }
    	      ];
    	 
    	      $http.get('cars/carlist.json')
    	        .success(function(data) {
    	          for(i = 0; i < data.length; i++){
    	            data[i].subGridOptions = {
    	              columnDefs: [ {name:"Id", field:"id"},{name:"Name", field:"name"} ],
    	              data: data[i].friends
    	            }
    	          }
    	          $scope.gridOptions.data = data;
    	        });
    	    }]);
    	 
    	app.controller('myController', ['$scope', '$http', '$log', function ($scope, $http, $log) {
    	      $scope.gridOptions = {
    	        expandableRowTemplate: 'subgrid.html',
    	        expandableRowHeight: 150,
    	        onRegisterApi: function (gridApi) {
    	            gridApi.expandable.on.rowExpandedStateChanged($scope, function (row) {
    	                if (row.isExpanded) {
    	                  row.entity.subGridOptions = {
    	                    columnDefs: [
    	                    { name: 'name'},
    	                    { name: 'gender'},
    	                    { name: 'company'}
    	                  ]};
    	 
    	                  $http.get('cars/carlist.json')
    	                    .success(function(data) {
    	                      row.entity.subGridOptions.data = data;
    	                    });
    	                }
    	            });
    	        }
    	      }
    	 
    	      $scope.gridOptions.columnDefs = [
    	    	  { field: 'customerId',pinnedLeft:true},
    	    		{ field: 'salutation' },
    	    		{ field: 'customerName' },
    	    		{ field: 'gender' },
    	    		{ field: 'dob' },
    	    		{ field: 'custAge' },
    	    		{ field: 'education' },
    	    		{ field: 'occupationName' },
    	    		{ field: 'maritalStatus' },
    	    		{ field: 'address' },
    	    		{ field: 'zipCode' },
    	    		{ field: 'phone' },
    	    		{ field: 'employer' },
    	    		
    	    		{ field: 'email' }
    	      ];
    	 
    	      $http.get('cars/carlist.json').success(function(carList){
    	             $scope.cars = carList;
    	         	$scope.gridOptions.data = $scope.cars; 
    	         	console.log( $scope.cars);
    	         });
    	    
    	    }]);
    	app.controller('myController1', ['$scope', '$http', '$log', function ($scope, $http, $log) {
    	      $scope.gridOptions = {
    	        enableRowSelection: true,
    	        expandableRowTemplate: 'subgrid.html',
    	        expandableRowHeight: 150
    	      }
    	 
    	      $scope.gridOptions.columnDefs = [
    	    	  { field: 'customerId',pinnedLeft:true},
  	    		{ field: 'salutation' },
  	    		{ field: 'customerName' },
  	    		{ field: 'gender' },
  	    		{ field: 'dob' },
  	    		{ field: 'custAge' },
  	    		{ field: 'education' },
  	    		{ field: 'occupationName' },
  	    		{ field: 'maritalStatus' },
  	    		{ field: 'address' },
  	    		{ field: 'zipCode' },
  	    		{ field: 'phone' },
  	    		{ field: 'employer' },
  	    		
  	    		{ field: 'email' }
    	      ];
    	 
    	      $http.get('cars/carlist.json')
    	        .success(function(data) {
    	          for(i = 0; i < data.length; i++){
    	            data[i].subGridOptions = {
    	              columnDefs: [ {name:"Id", field:"id"},{name:"Name", field:"name"} ],
    	              data: data[i].friends,
    	              disableRowExpandable : (i % 2 === 0)
    	            }
    	          }
    	          $scope.gridOptions.data = data;
    	        });
    	      
    	      
	$scope.users = [
					{ name: "Madhav Sai", age: 10, location: 'Nagpur' },
					{ name: "Suresh Dasari", age: 30, location: 'Chennai' },
					{ name: "Rohini Alavala", age: 29, location: 'Chennai' },
					{ name: "Praveen Kumar", age: 25, location: 'Bangalore' },
					{ name: "Sateesh Chandra", age: 27, location: 'Vizag' },
					{ name: "Siva Prasad", age: 38, location: 'Nagpur' },
					{ name: "Sudheer Rayana", age: 25, location: 'Kakinada' },
					{ name: "Honey Yemineni", age: 7, location: 'Nagpur' },
					{ name: "Mahendra Dasari", age: 22, location: 'Vijayawada' },
					{ name: "Mahesh Dasari", age: 23, location: 'California' },
					{ name: "Nagaraju Dasari", age: 34, location: 'Atlanta' },
					{ name: "Gopi Krishna", age: 29, location: 'Repalle' },
					{ name: "Sudheer Uppala", age: 19, location: 'Guntur' },
					{ name: "Sushmita", age: 27, location: 'Vizag' }
					];


	
    $scope.fetchCarsList();
    
    $scope.openCity =function (cityName) {
    	alert('hi');
        var i;
        var x = document.getElementsByClassName("city");
        for (i = 0; i < x.length; i++) {
           x[i].style.display = "none";  
        }
        document.getElementById(cityName).style.display = "block";  
    }
    
    $scope.shruti =function () {
      alert('hi');
    }
    
    
    
}]);