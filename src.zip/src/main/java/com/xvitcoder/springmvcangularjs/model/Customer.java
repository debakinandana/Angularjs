package com.xvitcoder.springmvcangularjs.model;

public class Customer {
private String documentName;
private String customerId;
private String custAge;
private String gender;
private String income;
private String location;
private String occupationName;
public String customerName;
private int pageCount;
private String recordCount;
private String salutation;
private String prefName;
public String getMaritalStatus() {
	return maritalStatus;
}
public void setMaritalStatus(String maritalStatus) {
	this.maritalStatus = maritalStatus;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getAnniversaryDate() {
	return anniversaryDate;
}
public void setAnniversaryDate(String anniversaryDate) {
	this.anniversaryDate = anniversaryDate;
}
private String dob;
private String education;
private String address;
private String employer;
private String email;
private String maritalStatus;
private String phone;
private String anniversaryDate;
public String getSalutation() {
	return salutation;
}
public void setSalutation(String salutation) {
	this.salutation = salutation;
}
public String getPrefName() {
	return prefName;
}
public void setPrefName(String prefName) {
	this.prefName = prefName;
}
public String getDob() {
	return dob;
}
public void setDob(String dob) {
	this.dob = dob;
}
public String getEducation() {
	return education;
}
public void setEducation(String education) {
	this.education = education;
}
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getEmployer() {
	return employer;
}
public void setEmployer(String employer) {
	this.employer = employer;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getRecordCount() {
	return recordCount;
}
public void setRecordCount(String recordCount) {
	this.recordCount = recordCount;
}

public String getCustomerName() {
	return customerName;
}
public void setCustomerName(String customerName) {
	this.customerName = customerName;
}
public String getDocumentName() {
	return documentName;
}
public void setDocumentName(String documentName) {
	this.documentName = documentName;
}
private String zipCode;
private String deniedClaims;
private String agencyName;
private String locationOfService;

public String getOccupationName() {
	return occupationName;
}
public void setOccupationName(String occupationName) {
	this.occupationName = occupationName;
}

public String getZipCode() {
	return zipCode;
}
public void setZipCode(String zipCode) {
	this.zipCode = zipCode;
}
public String getDeniedClaims() {
	return deniedClaims;
}
public void setDeniedClaims(String deniedClaims) {
	this.deniedClaims = deniedClaims;
}
public String getAgencyName() {
	return agencyName;
}
public void setAgencyName(String agencyName) {
	this.agencyName = agencyName;
}
public String getLocationOfService() {
	return locationOfService;
}
public void setLocationOfService(String locationOfService) {
	this.locationOfService = locationOfService;
}

public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}

public String getCustomerId() {
	return customerId;
}
public void setCustomerId(String customerId) {
	this.customerId = customerId;
}
public String getCustAge() {
	return custAge;
}
public void setCustAge(String custAge) {
	this.custAge = custAge;
}
public String getIncome() {
	return income;
}
public void setIncome(String income) {
	this.income = income;
}

public int getPageCount() {
	return pageCount;
}
public void setPageCount(int pageCount) {
	this.pageCount = pageCount;
}
public String getLocation() {
	return location;
}
public void setLocation(String location) {
	this.location = location;
}
}
