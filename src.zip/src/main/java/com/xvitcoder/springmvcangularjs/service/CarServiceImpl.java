package com.xvitcoder.springmvcangularjs.service;

import org.springframework.stereotype.Service;

import com.xvitcoder.springmvcangularjs.model.Customer;

import java.util.ArrayList;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: xvitcoder
 * Date: 12/20/12
 * Time: 11:14 PM
 */
@Service("carService")
public class CarServiceImpl implements CarService {
    private static List<Customer> carList = new ArrayList<Customer>();

    @Override
    public List<Customer> getAllCars() {
        return carList;
    }

    @Override
    public void addCar(Customer car) {
        carList.add(car);
    }

    @Override
    public void deleteCar(Customer car) {
        if (carList.contains(car)) {
            carList.remove(car);
        }
    }

    @Override
    public void deleteAll() {
        carList.clear();
    }
}
