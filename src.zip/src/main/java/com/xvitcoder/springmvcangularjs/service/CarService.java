package com.xvitcoder.springmvcangularjs.service;

import java.util.List;

import com.xvitcoder.springmvcangularjs.model.Customer;

/**
 * Created with IntelliJ IDEA.
 * User: xvitcoder
 * Date: 12/20/12
 * Time: 11:12 PM
 */
public interface CarService {
    public List<Customer> getAllCars();

    public void addCar(Customer car);

    public void deleteCar(Customer car);

    public void deleteAll();
}
