package com.xvitcoder.springmvcangularjs.config;

import org.springframework.context.annotation.Configuration;

/**
 * Created by xvitcoder on 12/24/15.
 */
@Configuration
public class AppConfig {
}
