angular.module('sdmApp', ['ngAnimate', 'ui.router', 'ui.bootstrap', 'ngScrollbars', 'oc.lazyLoad', 'angularUtils.directives.uiBreadcrumbs', 'angular-appinsights'])
    .run(function ($rootScope) {
        $rootScope.$on('$stateChangeSuccess', function (event, toState, toParams) {
            $rootScope.title = toState.title;
        });
    }).config(['$httpProvider', 'insightsProvider', 'URLSProvider', '$compileProvider', function ($httpProvider, insightsProvider, URLSProvider, $compileProvider) {

        $httpProvider.interceptors.push('LoadingInterceptor');
        insightsProvider.start(URLSProvider.$get().instrumentationKey);
        $compileProvider.aHrefSanitizationWhitelist(/^\s*(https?|ftp|mailto|file|sms|tel|javascript):/); // to handle unsafe urls with anchor links
    }]).directive('ckEditor', function () {
        return {
            require: '?ngModel',
            link: function (scope, elm, attr, ngModel) {
                var ck = CKEDITOR.replace(elm[0]);
                if (!ngModel) return;
                ck.on('instanceReady', function () {
                    ck.setData(ngModel.$viewValue);
                });
                function updateModel() {
                    scope.$apply(function () {
                        ngModel.$setViewValue(ck.getData());
                    });
                }
                ck.on('change', updateModel);
                ck.on('key', updateModel);
                ck.on('dataReady', updateModel);

                ngModel.$render = function (value) {
                    ck.setData(ngModel.$viewValue);
                };
            }
        };
    })
    .service('LoadingInterceptor', ['$q', '$rootScope', '$log', '$injector',
        function ($q, $rootScope, $log, $injector) {
            'use strict';
            var requestUrlCount = 0, configUrlList = [];
            var xhrCreations = 0;
            var xhrResolutions = 0;

            function isLoading() {
                return xhrResolutions < xhrCreations;
            }

            function updateStatus() {
                $rootScope.isViewLoading = isLoading();
            }
            function resolveRequestConfig(config) { // checks for site refresh on every request if  '/api/CheckSiteRefreshing' returns 'siteRefresh' flag as true cancel all request else return the config object
                var delayedPromise = delayedPromise || $q.defer();
                if (config.url.search('.html') >= 0 || config.url.search('.js') >= 0 || config.url.search('.css') >= 0 || config.url.search('.json') >= 0) { // generic file request urls
                    delayedPromise.resolve(config);
                }
                else {
                    if (config.url.search('/api/CheckSiteRefreshing') >= 0 /*|| config.url.search('SDMRefresh') >= 0 || config.url.search('admin') >= 0 || config.url.search('/api/images') >= 0*/) { // admin api urls
                        delayedPromise.resolve(config);
                    }
                    else { // api urls to get data from server
                        configUrlList.push({
                            showMessage: true,
                            configUrl: config.url,
                            toasterShown: true
                        })
                        requestUrlCount += config.url ? 1 : 0;
                        var $http = $http || $injector.get('$http'), alerting = alerting || $injector.get('alerting');
                        $http.get('/api/CheckSiteRefreshing').success(function (response) {
                            $rootScope.siteRefresh = response.siteRefresh;
                            if (response.siteRefresh) {
                                config.data = "site is refreshing aborting all api requests"
                                if (configUrlList[configUrlList.length - 1].showMessage) {
                                    configUrlList[configUrlList.length - 1].showMessage = true;
                                    configUrlList[configUrlList.length - 1].toasterShown = false;
                                }
                                configUrlList.forEach(function (messageObj) {
                                    if (messageObj.showMessage && !messageObj.toasterShown) {
                                        $rootScope.siteRefresh
                                        alerting.addAlert('danger', config.url.search('api/SDMRefresh') >= 0 ? 'Site Refresh is already under progress try after some time' : 'We are making some content updates and the site is being refreshed. Please try again after 5 minutes');
                                        messageObj.toasterShown = false;
                                        messageObj.showMessage = false;
                                    }
                                })
                                delayedPromise.reject(config);
                                // $rootScope.$emit('checkSiteRefresh', true);
                            }
                            else {
                                delayedPromise.resolve(config);
                            }
                        });

                    }
                }
                //setCorelationId(config);
                return delayedPromise.promise;
            }
            return {
                request: function (config) {
                    xhrCreations++;
                    updateStatus();
                    return resolveRequestConfig(config); // returns config object based on the request uri
                },
                requestError: function (rejection) {
                    xhrResolutions++;
                    updateStatus();
                    $log.error('Request error:', rejection);
                    return $q.reject(rejection);
                },
                response: function (response) {
                    xhrResolutions++;
                    updateStatus();
                    window.localStorage.setItem('key', angular.element("input[name='__RequestVerificationToken']").val());
                    return response;
                },
                responseError: function (rejection) {
                    xhrResolutions++;
                    updateStatus();
                    $rootScope.$emit('Service error', rejection);
                    $log.error('Response error:', rejection);
                    return $q.reject(rejection);
                }
            };
        }
    ]);
